9
/////////////////////////////////////////
// STAY SHARK v1 - Outubro 2019        //
// by Daniel Moura e Marcelo Marcolino //
/////////////////////////////////////////

//---------------------
// Inicializando Phaser
//---------------------

var config = {
	type: Phaser.AUTO,
    width: 800,
    height: 450,
	scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH
    },
	input: {
        activePointers: 3
    },
	pixelArt: true,
	//zoom: 2,
	backgroundColor: 0x000000,
    scene: { init: init, preload: preload, create: create, update: update, render: render }
}
var game = new Phaser.Game(config);

//----------
// Variáveis
//----------

var frames=0;
var angulo=0;
var intervalo=0;
var proximo_intervalo=50;
var pontos=0;
var ondas=1;
var fimDeJogo = 0;
var x=100;
var y=225;
var bocaAberta=0;
var obj_explosion;
var gameItens;
var str_debug;
var str_pontos;
var str_ondas;
var keySPACE;
var snd_bg_music;

//---------------
// Funcoes Phaser
//---------------

function init ()
{
}

function preload ()
{
	//imagens e audio
	//this.load.image('spr', 'img/spr.png');
	//this.load.spritesheet('anim', 'img/anim.png',{ frameWidth: 15, frameHeight: 30 });
	//this.load.audio('audio', ['snd/audio.wav']);
	this.load.image('spr_bg', 'img/spr_bg.png');
	this.load.spritesheet('spr_shark', 'img/spr_shark.png',{ frameWidth: 170, frameHeight: 110 });
	this.load.image('spr_atum', 'img/spr_atum.png');
	this.load.image('spr_mina', 'img/spr_mina.png');
	this.load.spritesheet('spr_explosion', 'img/spr_explosion.png',{ frameWidth: 240, frameHeight: 240 });
	this.load.image('spr_gameover', 'img/spr_gameover.png');
	this.load.image('spr_restart', 'img/spr_restart.png');
	this.load.audio('bg_music', ['snd/bg_music.mp3']);
	this.load.audio('snd_explosao', ['snd/snd_explosao.wav']);
	this.load.audio('snd_nhac', ['snd/snd_nhac.wav']);
}

function create ()
{
	cursors = this.input.keyboard.createCursorKeys(); //inicia teclado
	obj_bg = this.add.tileSprite(0, 0, 800, 450, 'spr_bg').setOrigin(0, 0);
	obj_bg.depth=-10;
	obj_shark = this.add.sprite(x, y, 'spr_shark').setOrigin(0.5, 0.5);
	str_debug = this.add.text(20, 20, '', { fontFamily: 'Verdana', fontSize: '16px', fill: '#FFFFFF' }).setScrollFactor(0);
	str_pontos = this.add.text(400, 20, '', { fontFamily: 'Verdana', fontSize: '40px', fill: '#FFFFFF' }).setScrollFactor(0);
	str_ondas = this.add.text(790, 440, '', { fontFamily: 'Verdana', fontSize: '20px', fill: '#FFFFFF' }).setScrollFactor(0);
	//str_debug.setShadow(2, 2, 'rgba(0,0,0,0.5)', 0);
	str_pontos.setShadow(2, 2, 'rgba(0,0,0,0.5)', 0);
	str_ondas.setShadow(2, 2, 'rgba(0,0,0,0.5)', 0);
	str_pontos.setOrigin(0.5,0);
	str_ondas.setOrigin(1,1);
	this.Group_Atum = this.add.group({runChildUpdate:true});
	this.Group_Mina = this.add.group({runChildUpdate:true});
	
	this.anims.create({
		key: 'parado',
		frames: [ { key: 'spr_shark', frame: 1 } ],
		frameRate: 20
	});
	this.anims.create({
		key: 'comendo',
		frames: [ { key: 'spr_shark', frame: 0 } ],
		frameRate: 20
	});
	this.anims.create({
		key: 'morto',
		frames: [ { key: 'spr_shark', frame: 2 } ],
		frameRate: 20
	});
	this.anims.create({
		key: 'explosao', 
		frames: this.anims.generateFrameNumbers('spr_explosion'), 
		frameRate: 20,	
		repeat: 0 //<- nao repetir esta animacao!
	});
	obj_shark.play('parado', true);
	
	snd_bg_music = this.sound.add('bg_music'); 
	snd_bg_music.loop = true;
	snd_bg_music.play();
}

function update ()
{
	frames ++;
	
	if(fimDeJogo==0){ 
	
		intervalo++; 
		
		//PLAYER//
		//desce
		if (cursors.up.isDown) { y-=4; }
		if (cursors.left.isDown) { y-=4; }
		if(this.input.activePointer.x>400 && game.input.activePointer.isDown){ y-=4; } //<- smartphone
		if( y>380 ){ y=380; }
		//sobe
		if (cursors.down.isDown) { y+=4; }
		if (cursors.right.isDown) { y+=4; }
		if(this.input.activePointer.x<400 && game.input.activePointer.isDown){ y+=4; } //<- smartphone
		if( y<70 ){ y=70; }
		obj_shark.x = x;
		obj_shark.y = y;
		
		obj_shark.x = x + 10 * Math.cos(Phaser.Math.DegToRad(angulo));
		obj_shark.y = y + 20 * Math.sin(Phaser.Math.DegToRad(angulo));
		obj_bg.tilePositionX+=3;
		
		angulo +=3;
		if(angulo>360) { angulo=0; };
		
		if(bocaAberta>0 && fimDeJogo==0){ 
			if(bocaAberta==20){this.sound.add('snd_nhac').play();}
			bocaAberta--; 
			if(bocaAberta==0){ obj_shark.play('parado', true); }
		}
		
		if(intervalo>proximo_intervalo){
			intervalo=0;
			proximo_intervalo=Phaser.Math.Between(20, 40);
			//cria atuns
			this.Group_Atum.add(atum = new Atum(this)); //sempre garante que pelo menos 1 apareca a cada intervalo
			if(frames>1000){ondas=2; this.Group_Atum.add(atum = new Atum(this));} //+1
			if(frames>2000){ondas=3; this.Group_Atum.add(atum = new Atum(this));} //+1
			if(frames>3000){ondas=4; this.Group_Atum.add(atum = new Atum(this));} //+1
			if(frames>4000){ondas=5; this.Group_Atum.add(atum = new Atum(this));} //...
			if(frames>5000){ondas=6; this.Group_Atum.add(atum = new Atum(this));}
			if(frames>6000){ondas=7; this.Group_Atum.add(atum = new Atum(this));}
			if(frames>7000){ondas=8; this.Group_Atum.add(atum = new Atum(this));}
			if(frames>8000){ondas=9; this.Group_Atum.add(atum = new Atum(this));}
			if(frames>9000){ondas=10; this.Group_Atum.add(atum = new Atum(this));}
			//cria minas
			if(ondas== 1){ var s=Phaser.Math.Between(0, 100); if(s<=  0){this.Group_Mina.add(mina = new Mina(this));}} //0% de chance
			if(ondas== 2){ var s=Phaser.Math.Between(0, 100); if(s<= 10){this.Group_Mina.add(mina = new Mina(this));}} 
			if(ondas== 3){ var s=Phaser.Math.Between(0, 100); if(s<= 20){this.Group_Mina.add(mina = new Mina(this));}} 
			if(ondas== 4){ var s=Phaser.Math.Between(0, 100); if(s<= 30){this.Group_Mina.add(mina = new Mina(this));}} 
			if(ondas== 5){ var s=Phaser.Math.Between(0, 100); if(s<= 40){this.Group_Mina.add(mina = new Mina(this));}} 
			if(ondas== 6){ var s=Phaser.Math.Between(0, 100); if(s<= 50){this.Group_Mina.add(mina = new Mina(this));}} 
			if(ondas== 7){ var s=Phaser.Math.Between(0, 100); if(s<= 60){this.Group_Mina.add(mina = new Mina(this));}} 
			if(ondas== 8){ var s=Phaser.Math.Between(0, 100); if(s<= 70){this.Group_Mina.add(mina = new Mina(this));}} 
			if(ondas== 9){ var s=Phaser.Math.Between(0, 100); if(s<= 80){this.Group_Mina.add(mina = new Mina(this));}} 
			if(ondas==10){ var s=Phaser.Math.Between(0, 100); if(s<= 90){this.Group_Mina.add(mina = new Mina(this));}} //90% de chance
		}
		
	}
	
	if(fimDeJogo==1 && frames==0){
		obj_explosion = this.add.sprite(obj_shark.x, obj_shark.y, 'spr_explosion').setOrigin(0.5, 0.5); 
		obj_explosion.flipX = 1;
		obj_explosion.play('explosao', true);
		obj_explosion.once(Phaser.Animations.Events.SPRITE_ANIMATION_COMPLETE, () => { obj_explosion.destroy();	})
		obj_shark.play('morto', true);
		obj_gameover = this.add.sprite(400, 225-80, 'spr_gameover').setOrigin(0.5, 0.5); 
		obj_restart = this.add.sprite(400, 225+100, 'spr_restart').setOrigin(0.5, 0.5).setInteractive();
		this.sound.add('snd_explosao').play();
		snd_bg_music.stop();
	}
	
	if(fimDeJogo==1){
		obj_restart.on('pointerover', function (pointer) { 
			//reinicia o jogo
			frames=0;
			angulo=0;
			intervalo=0;
			proximo_intervalo=50;
			pontos=0;
			ondas=1;
			fimDeJogo = 0;
			x=100;
			y=225;
			bocaAberta=0;
			obj_gameover.destroy();
			obj_restart.destroy();
			obj_shark.play('parado', true);
			snd_bg_music.play();
		});
	}
	
	/*
	str_debug.setText(
	'STAY SHARK' +
	'\nFrames: ' + frames + 
	'\nN.Peixes: ' + this.Group_Atum.getChildren().length + 
	'\nBoca Aberta: ' + bocaAberta
	);
	*/
	str_pontos.setText('PONTOS: ' + pontos);
	str_ondas.setText('ONDAS: ' + ondas);
}

function render ()
{
}

