class Mina extends Phaser.GameObjects.Sprite{
	constructor(scene){
		var x = 850;
		var y = Phaser.Math.Between(40, 410);
		super(scene, x, y, 'spr_mina').setOrigin(0.5, 0.5);
		//this.scene.add.existing(this);
		this.depth=-1;
		scene.add.existing(this);
	}
	update(){
		if(fimDeJogo==0){
			this.x-=5;
			if(this.x<-50){
				this.destroy();
			}
			if(Phaser.Math. Distance.Between(obj_shark.x, obj_shark.y, this.x, this.y)<50){
				frames = -1;
				fimDeJogo = 1;
				this.destroy();
			}
			this.x = this.x + 0 * Math.cos(Phaser.Math.DegToRad(angulo));
			this.y = this.y + 1 * Math.sin( Phaser.Math.DegToRad(angulo));
		}
		if(fimDeJogo==0 && frames==1){ this.destroy(); }
	}
}