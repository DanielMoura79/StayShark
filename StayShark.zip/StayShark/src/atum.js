class Atum extends Phaser.GameObjects.Sprite{
	constructor(scene){
		var x = 850;
		var y = Phaser.Math.Between(40, 410);
		super(scene, x, y, 'spr_atum').setOrigin(0.5, 0.5);
		//this.scene.add.existing(this);
		this.depth=-2;
		scene.add.existing(this);
	}
	update(){
		
		this.x-=Phaser.Math.Between(2, 8);
		if(this.x<-50){
			this.destroy();
		}
		if(fimDeJogo==0){
			if(Phaser.Math. Distance.Between(obj_shark.x, obj_shark.y, this.x, this.y)<50){
				pontos++;
				bocaAberta=20;
				obj_shark.play('comendo', true);
				this.destroy();
			}
		}
		if(fimDeJogo==0 && frames==1){ this.destroy(); }
		
		this.x = this.x + 0 * Math.cos(Phaser.Math.DegToRad(angulo));
		this.y = this.y + 1 * Math.sin( Phaser.Math.DegToRad( Phaser.Math.Between(0, 360)+angulo ) );
	}
}